package com.hms.profile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
