package com.hms.AdvMedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvMediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
