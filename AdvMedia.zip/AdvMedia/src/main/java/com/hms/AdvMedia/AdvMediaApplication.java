package com.hms.AdvMedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvMediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvMediaApplication.class, args);
	}

}
